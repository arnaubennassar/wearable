### Troubleshooting checklist

- [ ] I read the README (on master) thoroughly
- [ ] I ran the MAX30100_Tester and I'm going to paste the output down below
- [ ] I filled in all the details of my setup down below

### Description of the issue

### Output from MAX30100_Tester example

### Details of my setup

* Arduino hardware:
* MAX30100 breakout:
* Arduino framework version:
* MAX30100 library version:
